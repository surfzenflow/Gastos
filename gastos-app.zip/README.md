# Gastos

Offline living-costs tracker (daily / weekly / monthly). Installable on your phone's home screen.
All data stays on your device.
